
/* ---------------------------------------------------------------------- */
/* Target DBMS:           PostgreSQL 8                                    */
/* Project file:          MetaSoftware.dez                                */
/* Project name:          MetaSoftware                                    */
/* Author:                Tarlles Moreira da Cruz                         */
/* Script type:           Database creation script                        */
/* Created on:            2008-04-24 12:26                                */
/* Model version:         Version 2008-04-24                              */
/* ---------------------------------------------------------------------- */


/* ---------------------------------------------------------------------- */
/* CRIAR USU�RIO                                                          */
/* ---------------------------------------------------------------------- */
CREATE ROLE designcontexto LOGIN
  ENCRYPTED PASSWORD 'md5ff3911204ce44dfa37a9fbe8cf1ca1f8'
  SUPERUSER NOINHERIT NOCREATEDB CREATEROLE;
UPDATE pg_authid SET rolcatupdate=true WHERE OID=16384::oid;


/* ---------------------------------------------------------------------- */
/* CRIAR BANCO                                                            */
/* ---------------------------------------------------------------------- */
CREATE DATABASE designcontexto
  WITH OWNER = designcontexto
       ENCODING = 'UTF8'
       TABLESPACE = pg_default;


/* ---------------------------------------------------------------------- */
/* CRIAR SHEMA                                                            */
/* ---------------------------------------------------------------------- */
CREATE SCHEMA msf
       AUTHORIZATION designcontexto;


/* ---------------------------------------------------------------------- */
/* Tables                                                                 */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* Add TABLE "proprietario"                                               */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.proprietario_id_proprietario_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 5
  CACHE 1;

CREATE TABLE msf.proprietario (
    id_proprietario integer NOT NULL DEFAULT nextval('msf.proprietario_id_proprietario_seq'::regclass),
    str_nomeproprietario VARCHAR(70)  NOT NULL,
    str_profissaoproprietario VARCHAR(70),
    str_cpfproprietario VARCHAR(14) NOT NULL,
    str_nacionalidadeproprietario VARCHAR(40),
    str_naturalidadeproprietario VARCHAR(40),
    str_complemento VARCHAR(45) NOT NULL,
    id_numerocep integer NOT NULL,
    str_telresidencialproprietario VARCHAR(13),
    str_telcomercialproprietario VARCHAR(13),
    str_telcelularproprietario VARCHAR(13),
    str_emailproprietario VARCHAR(40),
    bln_vertelresidencialproprietario BOOLEAN DEFAULT TRUE,
    bln_vertelcomercialproprietario BOOLEAN DEFAULT TRUE,
    bln_vertelcelularproprietario BOOLEAN DEFAULT TRUE,
    bln_veremailproprietario BOOLEAN DEFAULT TRUE,
    CONSTRAINT PK_proprietario PRIMARY KEY (id_proprietario)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "imovel"                                                     */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.imovel_id_imovel_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 5
  CACHE 1;

CREATE TABLE msf.imovel (
    id_imovel integer NOT NULL DEFAULT nextval('msf.imovel_id_imovel_seq'::regclass),
    id_proprietario integer,
    str_tipoimovel VARCHAR(20),
    str_subtipoimovel VARCHAR(20),
    str_situacaoimovel VARCHAR(10)  NOT NULL,
    str_mobiliado VARCHAR(14),
    int_quarto INTEGER DEFAULT 0,
    int_sala INTEGER DEFAULT 0,
    int_banheiro INTEGER DEFAULT 0,
    int_suite INTEGER DEFAULT 0,
    int_garagem INTEGER DEFAULT 0,
    str_areaprivativa VARCHAR(30) DEFAULT '0',
    str_areaterreno VARCHAR(30) DEFAULT '0',
    str_areatotal VARCHAR(30) DEFAULT '0',
    str_unidadeprivativa  VARCHAR(25),
    str_unidadeterreno  VARCHAR(25),
    str_unidadetotal  VARCHAR(25),
    id_bairro integer NOT NULL,
    str_tiponegocio VARCHAR(10)  NOT NULL,
    str_subtiponegocio VARCHAR(9),
    str_valorimovel VARCHAR(30) DEFAULT '0',
    str_valoriptu VARCHAR(30) DEFAULT '0',
    str_valorcondominio VARCHAR(30) DEFAULT '0',
    str_valortaxasextras VARCHAR(30) DEFAULT '0',
    bln_vervalorimovel BOOLEAN DEFAULT TRUE,
    bln_vervaloroutros BOOLEAN DEFAULT TRUE,
    str_descricaoimovel TEXT,
    dt_entrega DATE,
    str_construtora VARCHAR(20),
    str_empreendimento VARCHAR(20),
    str_posicaosatelite TEXT,
    bln_promocao BOOLEAN DEFAULT FALSE  NOT NULL,
    dt_publicacao timestamp(6),
    bln_ativo BOOLEAN DEFAULT TRUE  NOT NULL,
    CONSTRAINT pk_imovel PRIMARY KEY (id_imovel),
    CONSTRAINT fk_imovel_proprietario FOREIGN KEY (id_proprietario)
        REFERENCES msf.proprietario (id_proprietario) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE SET NULL
);

CREATE INDEX ix_imovel_id_bairro
  ON msf.imovel
  USING btree
  (id_bairro);

CREATE INDEX ix_imovel_id_proprietario
  ON msf.imovel
  USING btree
  (id_proprietario);

/* ---------------------------------------------------------------------- */
/* Add TABLE "imagensimovel"                                              */
/* ---------------------------------------------------------------------- */


CREATE SEQUENCE msf.imagensimovel_id_imagensimovel_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 16
  CACHE 1;

CREATE TABLE msf.imagensimovel (
    id_imagensimovel integer NOT NULL  DEFAULT nextval('msf.imagensimovel_id_imagensimovel_seq'::regclass), 
    id_imovel INTEGER  NOT NULL,
    str_imagensimovel VARCHAR(20)  NOT NULL,
    str_diretorioimagensimovel VARCHAR(70)  NOT NULL,
    CONSTRAINT pk_imagensimovel PRIMARY KEY (id_imagensimovel),
    CONSTRAINT fk_imovel_imagensimovel FOREIGN KEY (id_imovel)
        REFERENCES msf.imovel (id_imovel) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE CASCADE
);

CREATE INDEX ix_imagensimovel_id_imovel
  ON msf.imagensimovel
  USING btree
  (id_imovel);

/* ---------------------------------------------------------------------- */
/* Add TABLE "arquivosimovel"                                             */
/* ---------------------------------------------------------------------- */


CREATE SEQUENCE msf.arquivosimovel_id_arquivosimovel_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 10
  CACHE 1;

CREATE TABLE msf.arquivosimovel (
    id_arquivosimovel integer NOT NULL  DEFAULT nextval('msf.arquivosimovel_id_arquivosimovel_seq'::regclass), 
    id_imovel INTEGER  NOT NULL,
    str_arquivosimovel VARCHAR(70)  NOT NULL,
    str_diretorioarquivosimovel VARCHAR(70)  NOT NULL,
    CONSTRAINT pk_arquivosimovel PRIMARY KEY (id_arquivosimovel),
    CONSTRAINT fk_imovel_arquivosimovel FOREIGN KEY (id_imovel)
        REFERENCES msf.imovel (id_imovel) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE CASCADE
);

CREATE INDEX ix_arquivosimovel_id_imovel
  ON msf.arquivosimovel
  USING btree
  (id_imovel);

/* ---------------------------------------------------------------------- */
/* Add TABLE "cotacao"                                                   */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.cotacao_id_cotacao_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 5
  CACHE 1;

CREATE TABLE msf.cotacao (
    id_cotacao integer NOT NULL  DEFAULT nextval('msf.cotacao_id_cotacao_seq'::regclass), 
    id_imovel INTEGER  NOT NULL,
    int_quantidadevisita INTEGER DEFAULT 0,
    int_quantidadebusca INTEGER DEFAULT 0,
    CONSTRAINT pk_cotacao PRIMARY KEY (id_cotacao),
    CONSTRAINT fk_imovel_cotacao FOREIGN KEY (id_imovel)
        REFERENCES msf.imovel (id_imovel) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE CASCADE
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "tipoimovel"                                                 */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.tipoimovel_id_tipoimovel_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 26
  CACHE 1;

CREATE TABLE msf.tipoimovel (
    id_tipoimovel integer NOT NULL  DEFAULT nextval('msf.tipoimovel_id_tipoimovel_seq'::regclass),
    str_tipoimovel VARCHAR(20)  NOT NULL,
    str_subtipoimovel VARCHAR(20),
    CONSTRAINT PK_tipoimovel PRIMARY KEY (id_tipoimovel)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "construtora"                                                */
/* ---------------------------------------------------------------------- */

CREATE TABLE msf.construtora (
    id_construtora SERIAL  NOT NULL,
    str_construtora VARCHAR(20)  NOT NULL,
    str_empreendimento VARCHAR(20)  NOT NULL,
    CONSTRAINT PK_construtora PRIMARY KEY (id_construtora)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "modalidadeimovel"                                           */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.modalidadeimovel_id_modalidadeimovel_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 5
  CACHE 1;

CREATE TABLE msf.modalidadeimovel (
    id_imovel integer NOT NULL,
    id_modalidadeimovel integer NOT NULL DEFAULT nextval('msf.modalidadeimovel_id_modalidadeimovel_seq'::regclass),
    bln_modalidade_01 BOOLEAN DEFAULT FALSE,
    str_modalidade_01 VARCHAR(6),
    bln_modalidade_02 BOOLEAN DEFAULT FALSE,
    str_modalidade_02 VARCHAR(19),
    bln_modalidade_03 BOOLEAN DEFAULT FALSE,
    str_modalidade_03 VARCHAR(15),
    bln_modalidade_04 BOOLEAN DEFAULT FALSE,
    str_modalidade_04 VARCHAR(25),
    bln_modalidade_05 BOOLEAN DEFAULT FALSE,
    str_modalidade_05 VARCHAR(13),
    bln_modalidade_06 BOOLEAN DEFAULT FALSE,
    str_modalidade_06 VARCHAR(8),
    bln_modalidade_07 BOOLEAN DEFAULT FALSE,
    str_modalidade_07 VARCHAR(24),
    bln_modalidade_08 BOOLEAN DEFAULT FALSE,
    str_modalidade_08 VARCHAR(22),
    bln_modalidade_09 BOOLEAN DEFAULT FALSE,
    str_modalidade_09 VARCHAR(21),
    bln_modalidade_10 BOOLEAN DEFAULT FALSE,
    str_modalidade_10 VARCHAR(19),
    bln_modalidade_11 BOOLEAN DEFAULT FALSE,
    str_modalidade_11 VARCHAR(14),
    bln_modalidade_12 BOOLEAN DEFAULT FALSE,
    str_modalidade_12 VARCHAR(7),
    bln_modalidade_13 BOOLEAN DEFAULT FALSE,
    str_modalidade_13 VARCHAR(7),
    bln_modalidade_14 BOOLEAN DEFAULT FALSE,
    str_modalidade_14 VARCHAR(15),
    bln_modalidade_15 BOOLEAN DEFAULT FALSE,
    str_modalidade_15 VARCHAR(7),
    bln_modalidade_16 BOOLEAN DEFAULT FALSE,
    str_modalidade_16 VARCHAR(18),
    bln_modalidade_17 BOOLEAN DEFAULT FALSE,
    str_modalidade_17 VARCHAR(15),
    bln_modalidade_18 BOOLEAN DEFAULT FALSE,
    str_modalidade_18 VARCHAR(17),
    bln_modalidade_19 BOOLEAN DEFAULT FALSE,
    str_modalidade_19 VARCHAR(6),
    bln_modalidade_20 BOOLEAN DEFAULT FALSE,
    str_modalidade_20 VARCHAR(7),
    bln_modalidade_21 BOOLEAN DEFAULT FALSE,
    str_modalidade_21 VARCHAR(7),
    bln_modalidade_22 BOOLEAN DEFAULT FALSE,
    str_modalidade_22 VARCHAR(7),
    bln_modalidade_23 BOOLEAN DEFAULT FALSE,
    str_modalidade_23 VARCHAR(14),
    bln_modalidade_24 BOOLEAN DEFAULT FALSE,
    str_modalidade_24 VARCHAR(10),
    CONSTRAINT PK_modalidadeimovel PRIMARY KEY (id_modalidadeimovel)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "theme"                                                      */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.theme_id_theme_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 7
  CACHE 1;

CREATE TABLE msf.theme (
    id_theme integer NOT NULL  DEFAULT nextval('msf.theme_id_theme_seq'::regclass),
    str_theme VARCHAR(15)  NOT NULL,
    str_dirtheme VARCHAR(70)  NOT NULL,
    str_dirmolde VARCHAR(20)  NOT NULL,
    str_dirimovel VARCHAR(10)  NOT NULL,
    str_dirarqimovel VARCHAR(15)  NOT NULL,
    str_dirminiimovel VARCHAR(10)  NOT NULL,
    str_diretorioicons VARCHAR(10)  NOT NULL,
    str_dirmoldegaleria VARCHAR(20)  NOT NULL,
    str_dirmoldegrupoes VARCHAR(25)  NOT NULL,
    str_dirmoldegrupodi VARCHAR(25)  NOT NULL,
    str_dirmolderesultado VARCHAR(25)  NOT NULL,
    str_dirmoldemostragaleria_01 VARCHAR(35)  NOT NULL,
    str_dirmoldemostragaleria_02 VARCHAR(35)  NOT NULL,
    str_dirmoldemostragaleria_03 VARCHAR(35)  NOT NULL,
    str_cortopgrupo VARCHAR(7)  NOT NULL,
    str_corfundogrupo VARCHAR(7)  NOT NULL,
    str_corfundogrupobranco VARCHAR(7),
    str_corfundoquadrolateral_01 VARCHAR(7),
    str_corfundoquadrolateral_02 VARCHAR(7),
    CONSTRAINT PK_theme PRIMARY KEY (id_theme)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "configuracao"                                               */
/* ---------------------------------------------------------------------- */


CREATE SEQUENCE msf.configuracao_id_configuracao_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 2
  CACHE 1;

CREATE TABLE msf.configuracao (
    id_configuracao  integer NOT NULL  DEFAULT nextval('msf.configuracao_id_configuracao_seq'::regclass), 
    id_theme INTEGER  NOT NULL,
    id_banner INTEGER  NOT NULL,
    str_nomesite VARCHAR(40)  NOT NULL,
    int_quantidadevisita INTEGER DEFAULT 0  NOT NULL,
    int_quantidadebusca INTEGER DEFAULT 0  NOT NULL,
    str_tipoinforme VARCHAR(15)  NOT NULL,
    int_quantidadeinformes INTEGER DEFAULT 1  NOT NULL,
    str_bannermediolargo VARCHAR(17)  NOT NULL,
    str_bannermediocurto VARCHAR(17)  NOT NULL,
    str_bannerbaixo VARCHAR(17)  NOT NULL,
    str_ufpadrao CHARACTER VARYING(2)  NOT NULL,
    str_emailchat text,
    CONSTRAINT pk_configuracao PRIMARY KEY (id_configuracao),
    CONSTRAINT fk_configuracao_theme FOREIGN KEY (id_theme)
        REFERENCES msf.theme (id_theme) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "empresa"                                                    */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.empresa_id_empresa_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 4
  CACHE 1;

CREATE TABLE msf.empresa (
    id_empresa integer NOT NULL DEFAULT nextval('msf.empresa_id_empresa_seq'::regclass),
    id_configuracao integer NOT NULL,
    str_tituloitem VARCHAR(90) NOT NULL,
    str_descricaoitem TEXT,
    dt_publicacao timestamp(6),
    CONSTRAINT pk_empresa PRIMARY KEY (id_empresa),
    CONSTRAINT fk_configuracao_empresa FOREIGN KEY (id_configuracao)
        REFERENCES msf.configuracao (id_configuracao) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION
);


/* ---------------------------------------------------------------------- */
/* Add TABLE "moldes"                                                     */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.moldes_id_moldes_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 5
  CACHE 1;

CREATE TABLE msf.moldes (
    id_moldes integer NOT NULL  DEFAULT nextval('msf.moldes_id_moldes_seq'::regclass),
    str_nomemolde VARCHAR(15)  NOT NULL,
    str_diretoriomolde VARCHAR(70)  NOT NULL,
    str_tipomolde VARCHAR(18)  NOT NULL,
    bln_modificar BOOLEAN DEFAULT TRUE,
    int_posicaox int4 NOT NULL DEFAULT 0,
    int_posicaoy int4 NOT NULL DEFAULT 0,
    int_posicaogx int4 NOT NULL DEFAULT 0,
    int_posicaogy int4 NOT NULL DEFAULT 0,
    CONSTRAINT PK_moldes PRIMARY KEY (id_moldes)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "banner"                                                     */
/* ---------------------------------------------------------------------- */


CREATE SEQUENCE msf.banner_id_banner_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 15
  CACHE 1;

CREATE TABLE msf.banner (
    id_banner integer NOT NULL  DEFAULT nextval('msf.banner_id_banner_seq'::regclass), 
    str_localbanner VARCHAR(18),
    str_nomebanner VARCHAR(40)  NOT NULL,
    str_diretoriobanner VARCHAR(70)  NOT NULL,
    dt_inicialbanner DATE  NOT NULL,
    dt_finalbanner DATE,
    str_titulobanner VARCHAR(43),
    str_chamadabanner VARCHAR(115),
    str_conteudobanner TEXT,
    str_url TEXT,
    str_localjanela varchar(12),
    bln_moldebanner BOOLEAN DEFAULT FALSE  NOT NULL,
    dt_publicacao timestamp(6),
    id_moldes INTEGER,
    CONSTRAINT pk_banner PRIMARY KEY (id_banner),
    CONSTRAINT fk_banner_moldes FOREIGN KEY (id_moldes)
        REFERENCES msf.moldes (id_moldes) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE SET NULL
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "plano"                                                     */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.plano_id_plano_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 4
  CACHE 1;

CREATE TABLE msf.plano (
    id_plano  integer NOT NULL  DEFAULT nextval('msf.plano_id_plano_seq'::regclass),
    str_nomeplano VARCHAR(20)  NOT NULL,
    bln_tipoinforme BOOLEAN DEFAULT FALSE  NOT NULL,
    int_quantidadeinformes INTEGER NOT NULL,
    bln_tipobanner BOOLEAN DEFAULT FALSE  NOT NULL,
    int_quantidadethemas INTEGER DEFAULT 1  NOT NULL,
    bln_quantidadevisitas BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_quantidadebuscas BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_construtoras BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_empreendimentos BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_subtipoimovel BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_valoriptu BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_valorcondominio BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_sala BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_banheiro BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_suite BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_garagem BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_uf BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_municipio BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_dtentrega BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_pacotediluido BOOLEAN,
    str_valorpacotesistema VARCHAR(8)  NOT NULL,
    str_valormensalsistema VARCHAR(8),
    CONSTRAINT PK_planos PRIMARY KEY (id_plano)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "contrato"                                                   */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.contrato_id_contrato_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 2
  CACHE 1;

CREATE TABLE msf.contrato (
    id_contrato integer NOT NULL DEFAULT nextval('msf.contrato_id_contrato_seq'::regclass),
    str_numerocontrato VARCHAR(20)  NOT NULL,
    str_nomeresponsavelcontrato VARCHAR(70)  NOT NULL,
    str_nomevendedorsistema VARCHAR(20)  NOT NULL,
    bln_pessoafisica BOOLEAN DEFAULT FALSE  NOT NULL,
    str_cnpj VARCHAR(18),
    str_cpf VARCHAR(14),
    str_complemento VARCHAR(45)  NOT NULL,
    id_numerocep integer NOT NULL,
    str_telefone VARCHAR(13)  NOT NULL,
    id_plano INTEGER  NOT NULL,
    dt_iniciovigencia DATE  NOT NULL,
    dt_finalvigencia DATE  NOT NULL,
    str_diavencimento CHARACTER(2),
    bln_contratoativo BOOLEAN DEFAULT TRUE  NOT NULL,
    CONSTRAINT pk_contrato PRIMARY KEY (id_contrato),
    CONSTRAINT fk_contrato_plano FOREIGN KEY (id_plano)
        REFERENCES msf.plano (id_plano) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE INDEX ix_contrato_id_plano
  ON msf.contrato
  USING btree
  (id_plano);


/* ---------------------------------------------------------------------- */
/* Add TABLE "boleto"                                                   */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.boleto_id_boleto_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 2
  CACHE 1;

CREATE TABLE msf.boleto (
    id_boleto integer NOT NULL DEFAULT nextval('msf.boleto_id_boleto_seq'::regclass),
    id_contrato INTEGER  NOT NULL,
    str_nossonumero VARCHAR(5)  NOT NULL,
    str_numerodocumento VARCHAR(12)  NOT NULL,
    dt_datavencimento DATE  NOT NULL,
    dt_datadocumento DATE  NOT NULL,
    dt_diareferecia  DATE  NOT NULL,
    str_valorboleto VARCHAR(30) DEFAULT '0',
    bln_boletoenviado BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_boletopago BOOLEAN DEFAULT FALSE  NOT NULL,
    CONSTRAINT pk_boleto PRIMARY KEY (id_boleto),
    CONSTRAINT fk_boleto_contrato FOREIGN KEY (id_contrato)
        REFERENCES msf.contrato (id_contrato) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE INDEX ix_boleto_id_boleto
  ON msf.boleto
  USING btree
  (id_contrato);


/* ---------------------------------------------------------------------- */
/* Add TABLE "usuario"                                                    */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.usuario_id_usuario_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 2
  CACHE 1;

CREATE TABLE msf.usuario (
    id_usuario integer NOT NULL  DEFAULT nextval('msf.usuario_id_usuario_seq'::regclass),
    id_contrato integer,
    str_nome VARCHAR(70)  NOT NULL,
    str_senha VARCHAR(20)  NOT NULL,
    str_email VARCHAR(40)  NOT NULL,
    str_telefone varchar(13) NOT NULL,
    str_nivelacesso VARCHAR(7)  NOT NULL,
    str_nomeimobiliaria VARCHAR(40) ,
    CONSTRAINT pk_usuario PRIMARY KEY (id_usuario),
    CONSTRAINT fk_usuario_contrato FOREIGN KEY (id_contrato)
        REFERENCES msf.contrato (id_contrato) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "rss"                                                        */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.rss_id_rss_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 3
  CACHE 1;

CREATE TABLE msf.rss (
    id_rss integer NOT NULL DEFAULT nextval('msf.rss_id_rss_seq'::regclass),
    bln_externo BOOLEAN DEFAULT FALSE  NOT NULL,
    str_linkexterno VARCHAR(255),
    str_titulo VARCHAR(90),
    str_descricao TEXT,
    str_copyright VARCHAR(50),
    CONSTRAINT PK_rss PRIMARY KEY (id_rss)
);


/* ---------------------------------------------------------------------- */
/* Add TABLE "rssItem"                                                     */
/* ---------------------------------------------------------------------- */

CREATE SEQUENCE msf.rssitem_id_rssitem_seq
  INCREMENT 1
  MINVALUE 0
  MAXVALUE 9223372036854775807
  START 11
  CACHE 1;

CREATE TABLE msf.rssitem (
    id_rssitem integer NOT NULL DEFAULT nextval('msf.rssitem_id_rssitem_seq'::regclass),
    id_rss integer NOT NULL,
    str_tituloitem VARCHAR(90) NOT NULL,
    str_descricaoitem TEXT,
    dt_publicacao timestamp(6),
    CONSTRAINT pk_rssitem PRIMARY KEY (id_rssitem),
    CONSTRAINT fk_rssitem_rss FOREIGN KEY (id_rss)
        REFERENCES msf.rss (id_rss) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE CASCADE
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "newsletters"                                                */
/* ---------------------------------------------------------------------- */

CREATE TABLE msf.newsletters (
    id_newsletters serial  NOT NULL,
    str_nome VARCHAR(20)  NOT NULL,
    str_email VARCHAR(70)  NOT NULL,
    bln_ativo BOOLEAN DEFAULT FALSE  NOT NULL,
    bln_enviado BOOLEAN DEFAULT FALSE  NOT NULL,
    CONSTRAINT PK_newsletters PRIMARY KEY (id_newsletters)
);

/* ---------------------------------------------------------------------- */
/* Add TABLE "newslettersboletim"                                                */
/* ---------------------------------------------------------------------- */

CREATE TABLE msf.newslettersboletim (
    id_newslettersboletim SERIAL  NOT NULL,
    str_assunto VARCHAR(40)  NOT NULL,
    str_titulo VARCHAR(40)  NOT NULL,
    str_descricao TEXT,
    dt_publicacao timestamp(6),
    str_emailresposta VARCHAR(40)  NOT NULL,
    bln_enviarnewsletters bool NOT NULL DEFAULT false,
    str_diretorionewsletters varchar(50) NOT NULL,
    CONSTRAINT PK_newslettersboletim PRIMARY KEY (id_newslettersboletim)
);


/* ---------------------------------------------------------------------- */
/* DADOS TABELA theme 						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: theme
--
INSERT INTO "msf"."theme" ("id_theme", "str_theme", "str_dirtheme", "str_dirmolde", "str_dirimovel", "str_dirarqimovel", "str_dirminiimovel", "str_diretorioicons", "str_dirmoldegaleria", "str_dirmolderesultado", "str_dirmoldegrupoes", "str_dirmoldegrupodi", "str_dirmoldemostragaleria_01", "str_dirmoldemostragaleria_02", "str_dirmoldemostragaleria_03", "str_cortopgrupo", "str_corfundogrupo", "str_corfundogrupobranco", "str_corfundoquadrolateral_01", "str_corfundoquadrolateral_02") VALUES (1, 'Padrao', 'template1/', 'template1/moldes/', 'imovel/', 'arquivosImovel/', 'mini/', 'icons/', 'MbannerGaleria.png', 'MbannerGrupoRes_01.png', 'MbannerGrupoRes_02.png', 'MbannerGrupoRes_03.png', 'MbannerGrupoGaleriaRes_01.png', 'MbannerGrupoGaleriaRes_02.png', 'MbannerGrupoGaleriaRes_03.png', '#3196da','#e5f1f4', '#f9f9f9', '#e3eff2', '#d5e1e4');
-- GO
INSERT INTO "msf"."theme" ("id_theme", "str_theme", "str_dirtheme", "str_dirmolde", "str_dirimovel", "str_dirarqimovel", "str_dirminiimovel", "str_diretorioicons", "str_dirmoldegaleria", "str_dirmolderesultado", "str_dirmoldegrupoes", "str_dirmoldegrupodi", "str_dirmoldemostragaleria_01", "str_dirmoldemostragaleria_02", "str_dirmoldemostragaleria_03", "str_cortopgrupo", "str_corfundogrupo", "str_corfundogrupobranco", "str_corfundoquadrolateral_01", "str_corfundoquadrolateral_02") VALUES (2, 'Laranja', 'template2/', 'template2/moldes/', 'imovel/', 'arquivosImovel/', 'mini/', 'icons/', 'MbannerGaleria.png', 'MbannerGrupoRes_01.png', 'MbannerGrupoRes_02.png', 'MbannerGrupoRes_03.png', 'MbannerGrupoGaleriaRes_01.png', 'MbannerGrupoGaleriaRes_02.png', 'MbannerGrupoGaleriaRes_03.png', '#838363', '#e9f2e9', '#f9f9f9', '#e7f0e7', '#d9e2d9');
-- GO
INSERT INTO "msf"."theme" ("id_theme", "str_theme", "str_dirtheme", "str_dirmolde", "str_dirimovel", "str_dirarqimovel", "str_dirminiimovel", "str_diretorioicons", "str_dirmoldegaleria", "str_dirmolderesultado", "str_dirmoldegrupoes", "str_dirmoldegrupodi", "str_dirmoldemostragaleria_01", "str_dirmoldemostragaleria_02", "str_dirmoldemostragaleria_03", "str_cortopgrupo", "str_corfundogrupo", "str_corfundogrupobranco", "str_corfundoquadrolateral_01", "str_corfundoquadrolateral_02") VALUES (3, 'Marfin', 'template3/', 'template3/moldes/', 'imovel/', 'arquivosImovel/', 'mini/', 'icons/', 'MbannerGaleria.png', 'MbannerGrupoRes_01.png', 'MbannerGrupoRes_02.png', 'MbannerGrupoRes_03.png', 'MbannerGrupoGaleriaRes_01.png', 'MbannerGrupoGaleriaRes_02.png', 'MbannerGrupoGaleriaRes_03.png', '#6c849c', '#f1f1d9', '#f9f9f9', '#efefd7', '#e1e1c9');
-- GO
INSERT INTO "msf"."theme" ("id_theme", "str_theme", "str_dirtheme", "str_dirmolde", "str_dirimovel", "str_dirarqimovel", "str_dirminiimovel", "str_diretorioicons", "str_dirmoldegaleria", "str_dirmolderesultado", "str_dirmoldegrupoes", "str_dirmoldegrupodi", "str_dirmoldemostragaleria_01", "str_dirmoldemostragaleria_02", "str_dirmoldemostragaleria_03", "str_cortopgrupo", "str_corfundogrupo", "str_corfundogrupobranco", "str_corfundoquadrolateral_01", "str_corfundoquadrolateral_02") VALUES (4, 'Oliva', 'template4/', 'template4/moldes/', 'imovel/', 'arquivosImovel/', 'mini/', 'icons/', 'MbannerGaleria.png', 'MbannerGrupoRes_01.png', 'MbannerGrupoRes_02.png', 'MbannerGrupoRes_03.png', 'MbannerGrupoGaleriaRes_01.png', 'MbannerGrupoGaleriaRes_02.png', 'MbannerGrupoGaleriaRes_03.png', '#7e9605', '#eeefe9', '#f9f9f9', '#ecede7', '#dedfd9');
-- GO
INSERT INTO "msf"."theme" ("id_theme", "str_theme", "str_dirtheme", "str_dirmolde", "str_dirimovel", "str_dirarqimovel", "str_dirminiimovel", "str_diretorioicons", "str_dirmoldegaleria", "str_dirmolderesultado", "str_dirmoldegrupoes", "str_dirmoldegrupodi", "str_dirmoldemostragaleria_01", "str_dirmoldemostragaleria_02", "str_dirmoldemostragaleria_03", "str_cortopgrupo", "str_corfundogrupo", "str_corfundogrupobranco", "str_corfundoquadrolateral_01", "str_corfundoquadrolateral_02") VALUES (5, 'Lima Verao', 'template5/', 'template5/moldes/', 'imovel/', 'arquivosImovel/', 'mini/', 'icons/', 'MbannerGaleria.png', 'MbannerGrupoRes_01.png', 'MbannerGrupoRes_02.png', 'MbannerGrupoRes_03.png', 'MbannerGrupoGaleriaRes_01.png', 'MbannerGrupoGaleriaRes_02.png', 'MbannerGrupoGaleriaRes_03.png', '#819216', '#edf1dd', '#f9f9f9', '#ebefdb', '#dde1cd');
-- GO
INSERT INTO "msf"."theme" ("id_theme", "str_theme", "str_dirtheme", "str_dirmolde", "str_dirimovel", "str_dirarqimovel", "str_dirminiimovel", "str_diretorioicons", "str_dirmoldegaleria", "str_dirmolderesultado", "str_dirmoldegrupoes", "str_dirmoldegrupodi", "str_dirmoldemostragaleria_01", "str_dirmoldemostragaleria_02", "str_dirmoldemostragaleria_03", "str_cortopgrupo", "str_corfundogrupo", "str_corfundogrupobranco", "str_corfundoquadrolateral_01", "str_corfundoquadrolateral_02") VALUES (6, 'Agua Piscina', 'template6/', 'template6/moldes/', 'imovel/', 'arquivosImovel/', 'mini/', 'icons/', 'MbannerGaleria.png', 'MbannerGrupoRes_01.png', 'MbannerGrupoRes_02.png', 'MbannerGrupoRes_03.png', 'MbannerGrupoGaleriaRes_01.png', 'MbannerGrupoGaleriaRes_02.png', 'MbannerGrupoGaleriaRes_03.png', '#7f7f7f', '#d3f9ff', '#f9f9f9', '#cdf9ff', '#a8f4ff');
-- GO



COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA Moldes 						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: molde
--
INSERT INTO "msf"."moldes" ("id_moldes", "str_nomemolde", "str_diretoriomolde", "str_tipomolde", "bln_modificar", "int_posicaox", "int_posicaoy", "int_posicaogx", "int_posicaogy") VALUES (1, 'Padr�o', 'moldesGeral/MbannerTop.png', 'Banner Topo', FALSE, 0, 0, 0, 0);
-- GO
INSERT INTO "msf"."moldes" ("id_moldes", "str_nomemolde", "str_diretoriomolde", "str_tipomolde", "bln_modificar", "int_posicaox", "int_posicaoy", "int_posicaogx", "int_posicaogy") VALUES (2, 'QuadriLargo', 'moldesGeral/MbannerMed_01.png', 'Banner Medio Largo', FALSE, 560, 27, 560, 37);
-- GO
INSERT INTO "msf"."moldes" ("id_moldes", "str_nomemolde", "str_diretoriomolde", "str_tipomolde", "bln_modificar", "int_posicaox", "int_posicaoy", "int_posicaogx", "int_posicaogy") VALUES (3, 'QuadriCurto', 'moldesGeral/MbannerMed_02.png', 'Banner Medio Curto', FALSE, 264, 27, 264, 37);
-- GO
INSERT INTO "msf"."moldes" ("id_moldes", "str_nomemolde", "str_diretoriomolde", "str_tipomolde", "bln_modificar", "int_posicaox", "int_posicaoy", "int_posicaogx", "int_posicaogy") VALUES (4, 'Corte Curvo', 'moldesGeral/MbannerBotton.png', 'Banner Baixo', FALSE, 327, 42, 561, 90);
-- GO

COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA planos						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: planos
--
INSERT INTO "msf"."plano" ("id_plano", "str_nomeplano", "bln_tipoinforme", "int_quantidadeinformes", "bln_tipobanner", "int_quantidadethemas", "bln_quantidadevisitas", "bln_quantidadebuscas", "bln_construtoras", "bln_empreendimentos", "bln_subtipoimovel", "bln_valoriptu", "bln_valorcondominio", "bln_sala", "bln_banheiro", "bln_suite", "bln_garagem", "bln_uf", "bln_municipio", "bln_dtentrega", "bln_pacotediluido", "str_valorpacotesistema", "str_valormensalsistema") VALUES (1, 'Combo Premium', TRUE, 7, TRUE, 6, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, '4997.00', '497.00');
-- GO
INSERT INTO "msf"."plano" ("id_plano", "str_nomeplano", "bln_tipoinforme", "int_quantidadeinformes", "bln_tipobanner", "int_quantidadethemas", "bln_quantidadevisitas", "bln_quantidadebuscas", "bln_construtoras", "bln_empreendimentos", "bln_subtipoimovel", "bln_valoriptu", "bln_valorcondominio", "bln_sala", "bln_banheiro", "bln_suite", "bln_garagem", "bln_uf", "bln_municipio", "bln_dtentrega", "bln_pacotediluido", "str_valorpacotesistema", "str_valormensalsistema") VALUES (2, 'Profissional', TRUE, 3, TRUE, 2, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, '3554.00', '354.00');
-- GO
INSERT INTO "msf"."plano" ("id_plano", "str_nomeplano", "bln_tipoinforme", "int_quantidadeinformes", "bln_tipobanner", "int_quantidadethemas", "bln_quantidadevisitas", "bln_quantidadebuscas", "bln_construtoras", "bln_empreendimentos", "bln_subtipoimovel", "bln_valoriptu", "bln_valorcondominio", "bln_sala", "bln_banheiro", "bln_suite", "bln_garagem", "bln_uf", "bln_municipio", "bln_dtentrega", "bln_pacotediluido", "str_valorpacotesistema", "str_valormensalsistema") VALUES (3, 'Expresso', FALSE,  1, FALSE, 1, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, '2000.00', '200.00');
-- GO


COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA contrato					  	  */
/* ---------------------------------------------------------------------- */

-- USEGO

-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: contrato
--
INSERT INTO "msf"."contrato" ("id_contrato", "str_numerocontrato", "str_nomeresponsavelcontrato", "str_nomevendedorsistema", "bln_pessoafisica", "str_cnpj", "str_cpf", "str_complemento", "id_numerocep", "str_telefone", "id_plano", "dt_iniciovigencia", "dt_finalvigencia", "str_diavencimento", "bln_contratoativo") VALUES (1, '0000000000', 'Dono do Portal', 'Mercado Livre', TRUE, null, '000.000.000-00', 'casa 456', 70000000, '61 0000-0000', 1, '2008-04-01', '2011-04-01', '15', TRUE);
-- GO


COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA Usuario						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: usuario
--
INSERT INTO "msf"."usuario" ("id_usuario", "id_contrato", "str_nome", "str_senha", "str_email", "str_telefone", "str_nivelacesso", "str_nomeimobiliaria") VALUES (1, null, 'Responsavel do Portal', '00000', 'email@gmail.com', '61 0000-0000', 'Gestor', null);
-- GO
INSERT INTO "msf"."usuario" ("id_usuario", "id_contrato", "str_nome", "str_senha", "str_email", "str_telefone", "str_nivelacesso", "str_nomeimobiliaria") VALUES (2, 1, 'teste', '00000', 'teste@gmail.com', '61 0000-0000', 'Usuario', null);
-- GO

COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA tipoimovel 						  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: tipoimovel
--

-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(1, 'Apartamento', 'Apart-hotel');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(2, 'Apartamento', 'Cobertura');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(3, 'Apartamento', 'Comercial');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(4, 'Apartamento', 'Condominio');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(5, 'Apartamento', 'Duplex');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(6, 'Apartamento', 'Loft');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(7, 'Apartamento', 'Kitchenette');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(8, 'Apartamento', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(9, 'Area/Lote/Terreno', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(10, 'Casa', 'Cobertura');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(11, 'Casa', 'Comercial');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(12, 'Casa', 'Condom�nio');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(13, 'Casa', 'Geminada');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(14, 'Casa', 'Planta Alta');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(15, 'Casa', 'Planta Baixa');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(16, 'Casa', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(17, 'Chacara', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(18, 'Fazenda', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(19, 'Garagem', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(20, 'Hotel', 'Hotel-Fazenda');
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(21, 'Hotel', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(22, 'Ilha', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(23, 'Pousada', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(24, 'Sitio', null);
-- GO
INSERT INTO "msf"."tipoimovel" ("id_tipoimovel", "str_tipoimovel", "str_subtipoimovel") VALUES(25, 'Outros', null);

-- GO
COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* ********************* DADOS ABAIXO DE TESTE ************************** */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* DADOS TABELA configuracao					  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: configuracao
--
INSERT INTO "msf"."configuracao" ("id_configuracao", "id_theme", "id_banner", "str_nomesite", "int_quantidadevisita", "int_quantidadebusca", "str_tipoinforme", "int_quantidadeinformes", "str_bannermediolargo", "str_bannermediocurto", "str_bannerbaixo", "str_ufpadrao", "str_emailchat") VALUES (1, 2, 1, 'NOMEDOSEUPORTAL.com.br', 10, 10, 'Randomico', 7, 'Randomico', 'Randomico', 'Randomico', 'DF', 'http://www.google.com/talk/service/badge/Start?tk=z01q6amlq3achu343434km43ka1o0cmmf34534j41jqadklhsbsme2dnd07sre5iqgdr3ujmvvnbssjrlu5n1hv0478jcb51328vgjeuatghj3l4on9032lu1tjc7mr50snrv4p1bd5jc7s2ee27bvb4nl7uos4kj05cr5id3');
-- GO


COMMIT;
-- GO



/* ---------------------------------------------------------------------- */
/* DADOS TABELA Empresa						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: empresa
--

INSERT INTO "msf"."empresa" ("id_empresa", "id_configuracao", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (1, 1, 'Quem Somos', 'A <STRONG>Parkimovel</STRONG> e a empresa que vem desenvolvendo o projeto de um&nbspsistema web chamado <STRONG>Metasoftware</STRONG>, um projeto afim de atender corretores de im�veis e imobili�rias de uma forma mais r�pida, segura e eficaz, para vender comprar ou alugar os seus im�veis, compartilhando as suas carteiras filosofias e procedimentos na gest�o dos seus im�veis.<br><br><br />
<P>Resultado de um projeto criado em 2007 em Bras�lia, a Parkimovel nasceu em janeiro de 2007. <br><br>Hoje a Parkimovel vem para reunir importantes recursos tecnol�gicos afim de propiciar as imobili�rias e corretores de im�veis meios para prestarem servi�os na internet de qualidade para seus clientes em todo Pa�s.<br><br>Desde 2008 a Parkimovel tem um nova proposta organizacional que vem para atender �s novas requisi��es do mercado sobretudo de empresas de outras cidades e estados que desejam utilizar de seus servi�os.<br><br>Para isso a Parkimovel tem a sua estrutura operacional apresentando uma arquitetura unificada e bem elaborada. Dessa forma se ganha agilidade para atender � sua expans�o nacional e contemplar a demanda do mercado. <br><br>Conhe�a melhor as vantagens de sua empresa possuir um portal com o sistema da Parkimovel.</P>', '2007-01-01 00:00:00');
-- GO

INSERT INTO "msf"."empresa" ("id_empresa", "id_configuracao", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (2, 1, 'Perguntas e Respostas', '<STRONG>1.O que � a Parkimovel? <br></STRONG>A Parkimovel a empresa que vem desenvolvendo o projeto do sistema web chamado Metasoftware, um projeto criado para atender corretores e imobili�rias que trabalham anunciando seus im�veis e compartilhando as suas carteiras filosofias e procedimentos na gest�o dos seus im�veis. <br><br><STRONG>2.Como funciona a Parkimovel?<br></STRONG>A Parkimovel funciona na como um portal imobili�rio que pode compartilhar ou n�o o mesmo banco de dados. <br>A Parkimovel libera em tempo real todos os im�veis que entram para venda e loca��o. Essa estrutura permite potencializar os neg�cios para as imobili�rias e proporciona um atendimento muito mais r�pido e eficaz para os clientes.<br><br>Contratando a Parkimovel, voc� ter� a sua disposi��o este portal personalizado para sua imobili�ria, junto com um Sistema Online de Gerenciamento de Im�veis que funciona por tr�s do portal Imobili�rio integrado, adequado para Imobili�rias e Corretores de Im�veis.<br><br><STRONG>3.H� quanto tempo existe a Parkimovel? <br></STRONG>Resultado de um projeto criado em 2007 a Parkimovel nasceu em Bras�lia. Hoje a Parkimovel possui o mais r�pido e seguro sistema web que re�ne importantes funcionalidades e procedimentos para operar varias carteiras de im�veis com rapidez qualidade e seguran�a. <br><br><STRONG>4.A Rede atua em todo o Brasil? <br></STRONG>A Parkimovel e capaz de atuar em todo o territ�rio nacional oferecendo os seus servi�os para clientes de todo o Brasil. <br><br><STRONG>5.Qual a �rea de atua��o profissional da Parkimovel? <br></STRONG>A Parkimovel atua no desenvolvimento do Metasoftware e no seu suporte, treinamento e na loca��o da ferramenta para imobili�rias e grandes corretores de imoveis. <br><br><STRONG>6.Posso anunciar diretamente no site? <br></STRONG>Sim. Qualquer imobili�ria ou corretor de qualquer lugar do Brasil pode contratar os servi�os da Parkimovel para incluir, alugar vender ou doar an�ncios de im�veis no seu pr�prio portal. <br>O an�ncio � cobrado de acordo com o que o contratante do portal determinar nas configura��es do sistema Metasoftware, basta informar os dados que o sistema solicitar. <br><br><STRONG>7.Qual a vantagem de colocar a gest�o do seus im�veis para a venda ou loca��o na Parkimovel? <br></STRONG>As vantagens s�o muitas. Al�m de contar com a seguran�a e confiabilidade que s� o Metasoftware oferece a voc�, tamb�m poder� configurar o sistema para que o portal fique customizado para a sua empresa, mantendo a qualidade da informa��o e design nos padr�es da Parkimovel. <br><br>Gerencie seus imoveis disponibilizando as informa��es em tempo real para todos os seus corretores e clientes.<br><br>Poder� tamb�m incluir o im�vel na sua melhor qualidade visual, pois s� os melhores profissionais em design e programa��o poderiam fazer manualmente mas a Parkimovel automatizou tudo isso&nbspno Metasoftware, assim fica simples e r�pido para publicar e gerir seus im�veis na internet.<br><br>Podendo divulgar o mapa do im�vel e&nbspfacilitando que os visitantes indiquem o anuncio visitado a outros amigos pelo pr�prio portal ou at� mesmo fazer perguntas ao corretor do imovel.<br><br>O nosso sistema oferece de forma din�mica e automatizada&nbspcom a mesma praticidade com que se opera a sua caixa de email. <br><br>Quando utilizar o Metasoftware ele vai gerenciar os banners do portal, as noticias feeds automaticamente, alem de disponibilizar a integra��o com o melhor sistema de F�rum de discuss�o da internet produzido pelo <EM>PHPBB</EM> seus clientes e corretores poder�o acessar os t�picos e acompanhar mais facilmente as discuss�es evitando redund�ncias e tornando mais eficientes as retomadas aos temas como se fossem ininterruptos.<br><br>Com o nosso newslletters voc� poder� divulgar promo��es eventos ou qualquer outro informativo a todos os visitantes cadastrados no seu portal, at� o controle financeiro dos anunciantes no seu portal ser� executado de forma automatizada.<br><br>E tamb�m poder� usufruir da integra��o com o <STRONG>Google Analytics</STRONG> que � capaz de identificar al�m da tradicional taxa de exibi��o e hit de uma p�gina, localiza��o geogr�fica do visitante, forma com a qual chegou na p�gina (atrav�s de links de outros sites, buscador, AdSense ou diretamente pelo endere�o), sistema operacional, navegador, navegador e sistema operacional combinados e suas vers�es, resolu��o de tela, javascript habilitado, reprodutor de flash instalado, entre outros, em per�odos di�rios, semanais, mensais e anuais.<br><br>Voc� ter� sem nenhum custo adicional toda e qualquer atualiza��o e upgrades do projeto Metasoftware automaticamente. <br><br><STRONG>8.Posso incluir at� quantos an�ncios? <br></STRONG>A Parkimovel n�o limita o n�mero de publica��es dos seus im�veis para seus clientes. <br>As restri��es existem para os planos mais b�sicos a qual limita apenas a quantidade de an�ncios publicit�rios que sejam apresentados simultaneamente, nos planos mais completos o contratante poder� incluir an�ncios publicit�rios fixos, aleat�rios ou aleatorios por per�odo pr� determinado, para serem apresentados no seu portal. <br><br><STRONG>9.Por quanto tempo os an�ncios dos assinantes do meu portal ser� publicado? <br></STRONG>O an�ncio ser� publicado por at� 90 dias. Ap�s esse prazo se n�o for renovado ser� automaticamente desativado do sistema, podendo ser reativado futuramente caso seja necess�rio. <br><br><STRONG>10.Como os assinantes do portal contratado faz para prorrogar um an�ncio? <br></STRONG>Quando o an�ncio expirar em 90 dias o im�vel ser� desativado e o seu assinante receber� um email com uma op��o para reativar o im�vel por mais 90 dias. <br><br>Uma semana antes de seu an�ncio expirar o assinante receber� um email e um aviso em seu <STRONG></STRONG>celular avisando que o prazo est� acabando. <STRONG>� necess�rio que o celular esteja apto a receber email</STRONG>. <br><br><STRONG>11.A Parkimovel atua em qualquer regi�o? <br></STRONG>A Parkimovel pode atuar em todo territ�rio nacional. <br><br><STRONG>12.A Parkimovel fornece o endere�o do im�vel anunciado no portal? <br></STRONG>N�o,&nbspo pr�prio assinante ap�s ser&nbspdevidamente cadastrado decide se coloca ou n�o os dados para contato e/ou o endere�o do im�vel.<br><br><STRONG>13.Qual o valor que � cobrado por este servi�o?&nbsp<br></STRONG>N�o temos um valor fixo,&nbspo pr�prio contratante monta o&nbspvalor do seu plano, contate um de nossos vendedores e contrate o plano que te atenda melhor. <br><br><STRONG>14.Como fa�o para ter acesso aos im�veis da Parkimovel? <br></STRONG>O acesso poder� ser feito pelo&nbspendere�o do seu pr�prio portal que ficar� sujeito a disponibilidade de dominio caso ainda n�o seja registrado.', '2007-01-01 00:00:00'
);
-- GO

INSERT INTO "msf"."empresa" ("id_empresa", "id_configuracao", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (3, 1, 'Contratando o Servi�o', '<P>"A literatura � consensual em reconhecer que uma alian�a estrat�gica na forma de rede ocorre quando duas ou mais organiza��es decidem conjugar esfor�os para perseguir um objetivo estrat�gico comum. Dessa forma os parceiros procuram desenvolver uma vantagem cooperativa e competitiva que tenha efeitos positivos sobre o seu desempenho individual e coletivo. Esse modelo organizacional busca favorecer a atividade de cada uma delas sem que estas tenham for�osamente la�os financeiros entre si. As empresas em rede complementam-se umas �s outras nos planos t�cnicos e comerciais obtendo relevantes resultados decorrentes do ganho de escala e do compartilhamento de custos e benef�cios". Ariano Cavalcanti de Paula - autor da tese de mestrado: Rede organizacional: uma estrat�gia de desenvolvimento?</P><br />
<P>Numa rede de imobili�rias estas vantagens s�o ampliadas por meio do compartilhamento da carteira de im�veis e das pr�ticas comerciais. A maior efic�cia nos processos de venda compra e loca��o s�o benef�cios e vantagens competitivas diretamente percebidos pelos clientes. O resultado � imediato: melhor atendimento do cliente e mais neg�cios para as empresas da rede.</P><br />
<P>Segundo Porter as empresas que n�o buscarem um diferencial competitivo diante do contexto de concorr�ncia global que se apresenta v�o sucumbir. As alternativas para a sobreviv�ncia e desenvolvimento podem passar pelas alian�as estrat�gicas na forma de redes. Veja o caso Netim�veis.</P>', '2007-01-01 00:00:00');
-- GO

COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA banner						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: banner
--
INSERT INTO "msf"."banner" ("id_banner", "str_localbanner", "str_nomebanner", "str_diretoriobanner", "dt_inicialbanner", "dt_finalbanner", "str_titulobanner", "str_chamadabanner", "str_conteudobanner", "str_url", "str_localjanela", "bln_moldebanner", "id_moldes", "dt_publicacao") VALUES (1, 'Banner Topo', 'Banner Padrao', 'banners/banner_Tema_6.jpg', '2008-04-01', null, null, null, null, null, 'Mesma Janela', TRUE, 1, '2007-01-01 00:00:00');
-- GO
INSERT INTO "msf"."banner" ("id_banner", "str_localbanner", "str_nomebanner", "str_diretoriobanner", "dt_inicialbanner", "dt_finalbanner", "str_titulobanner", "str_chamadabanner", "str_conteudobanner", "str_url", "str_localjanela", "bln_moldebanner", "id_moldes", "dt_publicacao") VALUES (2, 'Banner Medio Largo', 'Banner Publicitario 1', 'banners/banner1.swf', '2008-04-01', '2009-04-01', null, null, null, null, 'Mesma Janela', FALSE, 2, '2007-01-01 00:00:00');
-- GO
INSERT INTO "msf"."banner" ("id_banner", "str_localbanner", "str_nomebanner", "str_diretoriobanner", "dt_inicialbanner", "dt_finalbanner", "str_titulobanner", "str_chamadabanner", "str_conteudobanner", "str_url", "str_localjanela", "bln_moldebanner", "id_moldes", "dt_publicacao") VALUES (4, 'Banner Baixo', 'Banner Anuncio 1', 'banners/banner3.jpg', '2008-04-01', '2009-04-01', 'Sonhos ao seu Alcance', 'Conhe�a as melhores formas de financiar o apartamento dos seus sonhos de acordocom o seu or�amento.', '<P>Conhe�a a melhor forma de <STRONG>financiar </STRONG>o seu apartamento, entre em contato com um de nossos vendedore e saiba a melhor forma de conquista o seu apartamento em <STRONG>Aguas Claras.</STRONG></P><P><STRONG><FONT color=#3366ff>Praticidade</FONT></STRONG></P><P><STRONG><FONT color=#3366ff>Seguran�a</FONT></STRONG></P><P><STRONG><FONT color=#3366ff>Localidade</FONT></STRONG></P><P><FONT color=#000000>Tudo mais proximo de voc�.</FONT></P>', null, 'Mesma Janela', TRUE, 4, '2007-01-01 00:00:00');
-- GO
INSERT INTO "msf"."banner" ("id_banner", "str_localbanner", "str_nomebanner", "str_diretoriobanner", "dt_inicialbanner", "dt_finalbanner", "str_titulobanner", "str_chamadabanner", "str_conteudobanner", "str_url", "str_localjanela", "bln_moldebanner", "id_moldes", "dt_publicacao") VALUES (5, 'Banner Medio Largo', 'Banner Publicitario 2', 'banners/banner1.swf', '2008-04-01', '2009-04-01', null, null, null, null, null, FALSE, 2, '2007-01-01 00:00:00');
-- GO
INSERT INTO "msf"."banner" ("id_banner", "str_localbanner", "str_nomebanner", "str_diretoriobanner", "dt_inicialbanner", "dt_finalbanner", "str_titulobanner", "str_chamadabanner", "str_conteudobanner", "str_url", "str_localjanela", "bln_moldebanner", "id_moldes", "dt_publicacao") VALUES (7, 'Banner Baixo', 'Banner Anuncio 2', 'banners/banner3.jpg', '2008-04-01', '2009-04-01', 'Informe o texto que voc� quiser', 'Conhe�a as melhores formas de financiar o apartamento dos seus sonhos de acordocom o seu or�amento.', '<P>Conhe�a a melhor forma de <STRONG>financiar </STRONG>o seu apartamento, entre em contato com um de nossos vendedore e saiba a melhor forma de conquista o seu apartamento em <STRONG>Aguas Claras.</STRONG></P><P><STRONG><FONT color=#3366ff>Praticidade</FONT></STRONG></P><P><STRONG><FONT color=#3366ff>Seguran�a</FONT></STRONG></P><P><STRONG><FONT color=#3366ff>Localidade</FONT></STRONG></P><P><FONT color=#000000>Tudo mais proximo de voc�.</FONT></P>', null, 'Mesma Janela', TRUE, 4, '2007-01-01 00:00:00');
-- GO


COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA proprietario					  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: proprietario
--
INSERT INTO "msf"."proprietario" ("id_proprietario", "str_nomeproprietario", "str_profissaoproprietario", "str_cpfproprietario", "str_nacionalidadeproprietario", "str_naturalidadeproprietario", "str_complemento", "id_numerocep", "str_telresidencialproprietario", "str_telcomercialproprietario", "str_telcelularproprietario", "str_emailproprietario", "bln_vertelresidencialproprietario", "bln_vertelcomercialproprietario", "bln_vertelcelularproprietario", "bln_veremailproprietario") VALUES (1, 'DonoImovelFulano', 'Advogado', '000.000.000-00', 'Brasileira', 'Brasiliense', 'casa 324', 71000000, '61 0000-0000', '61 0000-0000', '61 0000-0000', 'email@gmail.com', TRUE, TRUE, TRUE, TRUE);
-- GO

COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA Imovel						  	  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: imovel
--

INSERT INTO "msf"."imovel" ("id_imovel", "id_proprietario", "str_tipoimovel", "str_subtipoimovel", "str_situacaoimovel", "str_mobiliado", "int_quarto", "int_sala", "int_banheiro", "int_suite", "int_garagem", "str_areaprivativa", "str_areaterreno", "str_areatotal", "str_unidadeprivativa", "str_unidadeterreno", "str_unidadetotal", "id_bairro", "str_tiponegocio", "str_subtiponegocio", "str_valorimovel", "str_valoriptu", "str_valorcondominio", "str_valortaxasextras", "bln_vervalorimovel", "bln_vervaloroutros", "str_descricaoimovel", "dt_entrega", "str_construtora", "str_empreendimento", "str_posicaosatelite", "bln_promocao", "bln_ativo", "dt_publicacao") VALUES (1, 1, 'Casa', 'Planta Baixa', 'Usado', 'N�o Mobiliado', 1, 2, 1, 2, 1, '1000584', '85000584', '86001384', 'Alqueires do Norte', 'Hectar(es)', 'Alqueires Baianos', 32, 'Venda', null, '1298000.00', '2500.00', '1300.00', '100.00', TRUE, TRUE, 'Este espa�o e dedicado para breve descri��o do im�vel cadastrado lembrando que todos os dados informados sobre este im�vel e meramente para demonstra��o  de qualidade da informa��o cadastrada neste portal sobre a carteira de im�veis. Nenhum dado sobre este an�ncio e ver�dico.', null, null, null, '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com.br/?ie=UTF8&amp;ll=-15.798391,-47.875548&amp;spn=0.003675,0.004989&amp;t=h&amp;z=18&amp;output=embed&amp;s=AARTsJqzARj-Z8VnW5pkPMLMmZbqrJcYpw"></iframe>', TRUE, TRUE, '2007-01-01 00:00:00');
-- GO
-- GO
INSERT INTO "msf"."imovel" ("id_imovel", "id_proprietario", "str_tipoimovel", "str_subtipoimovel", "str_situacaoimovel", "str_mobiliado", "int_quarto", "int_sala", "int_banheiro", "int_suite", "int_garagem", "str_areaprivativa", "str_areaterreno", "str_areatotal", "str_unidadeprivativa", "str_unidadeterreno", "str_unidadetotal", "id_bairro", "str_tiponegocio", "str_subtiponegocio", "str_valorimovel", "str_valoriptu", "str_valorcondominio", "str_valortaxasextras", "bln_vervalorimovel", "bln_vervaloroutros", "str_descricaoimovel", "dt_entrega", "str_construtora", "str_empreendimento", "str_posicaosatelite", "bln_promocao", "bln_ativo", "dt_publicacao") VALUES (2, 1, 'Casa', 'Planta Alta', 'Usado', 'N�o Mobiliado', 3, 3, 2, 1, 4, '20024', '546534', '22115525', 'Alqueires Paulistas', 'Acres(s)', 'Alqueires Mineiros', 33, 'Venda', null, '198000.00', '3500.00', '1000.00', '20000.00', FALSE, FALSE, 'Este espa�o e dedicado para breve descri��o do im�vel cadastrado lembrando que todos os dados informados sobre este im�vel e meramente para demonstra��o  de qualidade da informa��o cadastrada neste portal sobre a carteira de im�veis. Nenhum dado sobre este an�ncio e ver�dico.', null, null, null,'<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com.br/?ie=UTF8&amp;ll=-15.798391,-47.875548&amp;spn=0.003675,0.004989&amp;t=h&amp;z=18&amp;output=embed&amp;s=AARTsJqzARj-Z8VnW5pkPMLMmZbqrJcYpw"></iframe>', FALSE, TRUE, '2007-01-01 00:00:00');
-- GO
-- GO
INSERT INTO "msf"."imovel" ("id_imovel", "id_proprietario", "str_tipoimovel", "str_subtipoimovel", "str_situacaoimovel", "str_mobiliado", "int_quarto", "int_sala", "int_banheiro", "int_suite", "int_garagem", "str_areaprivativa", "str_areaterreno", "str_areatotal", "str_unidadeprivativa", "str_unidadeterreno", "str_unidadetotal", "id_bairro", "str_tiponegocio", "str_subtiponegocio", "str_valorimovel", "str_valoriptu", "str_valorcondominio", "str_valortaxasextras", "bln_vervalorimovel", "bln_vervaloroutros", "str_descricaoimovel", "dt_entrega", "str_construtora", "str_empreendimento", "str_posicaosatelite", "bln_promocao", "bln_ativo", "dt_publicacao") VALUES (3, null, 'Apartamento', 'Cobertura', 'Lan�amento', 'Semi Mobiliado', 2, 1, 3, 3, 2, '5465564', '2898784', '363636636', 'Quilometro(s) Quadrados', 'Hectar(es)', 'Alqueires Mineiros', 34, 'Aluguel', 'Semanal', '575000000000.00', '1500000.00', '120000.00', '50.00', FALSE, TRUE, 'Este espa�o e dedicado para breve descri��o do im�vel cadastrado lembrando que todos os dados informados sobre este im�vel e meramente para demonstra��o  de qualidade da informa��o cadastrada neste portal sobre a carteira de im�veis. Nenhum dado sobre este an�ncio e ver�dico.', '2008-12-05', null, null, '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com.br/?ie=UTF8&amp;ll=-15.798391,-47.875548&amp;spn=0.003675,0.004989&amp;t=h&amp;z=18&amp;output=embed&amp;s=AARTsJqzARj-Z8VnW5pkPMLMmZbqrJcYpw"></iframe>', TRUE, TRUE, '2007-01-01 00:00:00');
-- GO
-- GO
INSERT INTO "msf"."imovel" ("id_imovel", "id_proprietario", "str_tipoimovel", "str_subtipoimovel", "str_situacaoimovel", "str_mobiliado", "int_quarto", "int_sala", "int_banheiro", "int_suite", "int_garagem", "str_areaprivativa", "str_areaterreno", "str_areatotal", "str_unidadeprivativa", "str_unidadeterreno", "str_unidadetotal", "id_bairro", "str_tiponegocio", "str_subtiponegocio", "str_valorimovel", "str_valoriptu", "str_valorcondominio", "str_valortaxasextras", "bln_vervalorimovel", "bln_vervaloroutros", "str_descricaoimovel", "dt_entrega", "str_construtora", "str_empreendimento", "str_posicaosatelite", "bln_promocao", "bln_ativo", "dt_publicacao") VALUES (4, null, 'Apartamento', 'Duplex', 'Lan�amento', 'Mobiliado', 5, 3, 4, 4, 4, '2121', '5454', '878784', 'Metro(s) Quadrados', 'Hectar(es)', 'Alqueires do Norte', 41, 'Aluguel', 'Di�ria', '28000.00', '2550.00', '2000.00', '2310.00', TRUE, FALSE, 'Este espa�o e dedicado para breve descri��o do im�vel cadastrado lembrando que todos os dados informados sobre este im�vel e meramente para demonstra��o  de qualidade da informa��o cadastrada neste portal sobre a carteira de im�veis. Nenhum dado sobre este an�ncio e ver�dico.', '2008-12-05', null, null, '<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com.br/?ie=UTF8&amp;ll=-15.798391,-47.875548&amp;spn=0.003675,0.004989&amp;t=h&amp;z=18&amp;output=embed&amp;s=AARTsJqzARj-Z8VnW5pkPMLMmZbqrJcYpw"></iframe>', FALSE, TRUE, '2007-01-01 00:00:00');
-- GO
COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA imagensimovel						  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: imagensimovel
--
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (1, 1, 'TesteImagem1', 'imovel.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (2, 1, 'TesteImagem2', 'imovel2.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (3, 2, 'TesteImagem3', 'imovel3.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (4, 1, 'TesteImagem4', 'imovel4.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (5, 1, 'TesteImagem5', 'imovel5.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (6, 4, 'TesteImagem6', 'imovel6.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (7, 2, 'TesteImagem7', 'imovel7.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (8, 4, 'TesteImagem8', 'imovel8.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (9, 3, 'TesteImagem9', 'imovel9.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (10, 3, 'TesteImagem10', 'imovel10.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (11, 4, 'TesteImagem11', 'imovel11.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (12, 2, 'TesteImagem12', 'imovel12.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (13, 4, 'TesteImagem13', 'imovel13.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (14, 4, 'TesteImagem14', 'imovel14.jpg');
-- GO
INSERT INTO "msf"."imagensimovel" ("id_imagensimovel", "id_imovel", "str_imagensimovel", "str_diretorioimagensimovel") VALUES (15, 3, 'TesteImagem15', 'imovel15.jpg');
-- GO


COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA arquivosimovel						  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: arquivosimovel
--
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (1, 1, 'Planejamento', 'imovel01.pdf');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (2, 1, 'Plantas Imovel', 'imovel02.doc');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (3, 2, 'Sonho do Lar', 'imovel03.xls');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (4, 2, 'Belos Apartamentos', 'imovel04.ppt');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (5, 2, 'Investimento Imobiliario', 'imovel05.zip');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (6, 3, 'Familia Feliz', 'imovel06.rar');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (7, 3, 'Obras e Plantas', 'imovel07.pdf');
-- GO
INSERT INTO "msf"."arquivosimovel" ("id_arquivosimovel", "id_imovel", "str_arquivosimovel", "str_diretorioarquivosimovel") VALUES (8, 4, 'Quarto e Sala', 'imovel08.pdf');
-- GO



COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA cotacao							  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: cotacao
--
INSERT INTO "msf"."cotacao" ("id_cotacao", "id_imovel", "int_quantidadevisita", "int_quantidadebusca") VALUES (1, 1, 1, 1);
-- GO
INSERT INTO "msf"."cotacao" ("id_cotacao", "id_imovel", "int_quantidadevisita", "int_quantidadebusca") VALUES (2, 2, 3, 2);
-- GO
INSERT INTO "msf"."cotacao" ("id_cotacao", "id_imovel", "int_quantidadevisita", "int_quantidadebusca") VALUES (3, 3, 2, 3);
-- GO
INSERT INTO "msf"."cotacao" ("id_cotacao", "id_imovel", "int_quantidadevisita", "int_quantidadebusca") VALUES (4, 4, 4, 4);
-- GO

COMMIT;
-- GO

/* ---------------------------------------------------------------------- */
/* DADOS TABELA modalidadeimovel					  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: modalidadeimovel
--

INSERT INTO "msf"."modalidadeimovel" ("id_imovel", "id_modalidadeimovel", "bln_modalidade_01", "str_modalidade_01", "bln_modalidade_02", "str_modalidade_02", "bln_modalidade_03", "str_modalidade_03", "bln_modalidade_04", "str_modalidade_04", "bln_modalidade_05", "str_modalidade_05", "bln_modalidade_06", "str_modalidade_06", "bln_modalidade_07", "str_modalidade_07", "bln_modalidade_08", "str_modalidade_08", "bln_modalidade_09", "str_modalidade_09", "bln_modalidade_10", "str_modalidade_10", "bln_modalidade_11", "str_modalidade_11", "bln_modalidade_12", "str_modalidade_12", "bln_modalidade_13", "str_modalidade_13", "bln_modalidade_14", "str_modalidade_14", "bln_modalidade_15", "str_modalidade_15", "bln_modalidade_16", "str_modalidade_16", "bln_modalidade_17", "str_modalidade_17", "bln_modalidade_18", "str_modalidade_18", "bln_modalidade_19", "str_modalidade_19", "bln_modalidade_20", "str_modalidade_20", "bln_modalidade_21", "str_modalidade_21", "bln_modalidade_22", "str_modalidade_22", "bln_modalidade_23", "str_modalidade_23", "bln_modalidade_24", "str_modalidade_24") VALUES (1, 1, TRUE, 'Alarme', TRUE, 'Aquecimento Central', TRUE, 'Ar Conficionado', TRUE, 'Banheira de Hidromassagem', TRUE, 'Churrasqueira', TRUE, 'Elevador', TRUE, 'Exposi��o Solar Nascente', TRUE, 'Exposi��o Solar Poente', TRUE, 'Exposi��o Solar Norte', TRUE, 'Exposi��o Solar Sul', TRUE, 'G�s Canalizado', TRUE, 'Jacuzzi', TRUE, 'Jardins', TRUE, 'Parque Infantil', TRUE, 'Piscina', TRUE, 'Porta de Seguran�a', TRUE, 'Quadra de Tenis', TRUE, 'Sala de Ginastica', TRUE, 'Sauna', TRUE, 'Terra�o', TRUE, 'Tv-Cabo', TRUE, 'Varanda', TRUE, 'Video Porteiro', TRUE, 'WC Servi�o');
-- GO

COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA rss							  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: rss
--
INSERT INTO "msf"."rss" ("id_rss", "bln_externo", "str_linkexterno", "str_titulo", "str_descricao", "str_copyright") VALUES (1, FALSE, null,'Mercado Imobiliario', 'Tudo que voce precisa saber sobre o mercado Imobiliario', '2008 DesingContext.com');
-- GO
INSERT INTO "msf"."rss" ("id_rss", "bln_externo", "str_linkexterno", "str_titulo", "str_descricao", "str_copyright") VALUES (2, TRUE, 'http://g1.globo.com/Rss2/0,,AS0-9356,00.xml',null, null, null);
-- GO

COMMIT;
-- GO


/* ---------------------------------------------------------------------- */
/* DADOS TABELA rssItem							  */
/* ---------------------------------------------------------------------- */

-- USEGO


-- GO
BEGIN;
-- GO

--
-- Dumping Table Data: rssitem
--
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (1, 1, 'Feir�o de im�veis da Caixa termina com recorde de p�blico e financiamentos.', 'A 4� edi��o do Feir�o de im�veis da Caixa Econ�mica Federal em S�o Paulo terminou neste domingo com recorde de p�blico e financiamentos, informou a organiza��o do evento.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (2, 1, 'Financiamento da casa pr�pria soma R$ 2 bilh�es em abril, diz Abecip.', 'Os financiamentos imobili�rios com recurso da poupan�a alcan�aram R$ 2,049 bilh�es em abril, o segundo melhor m�s j� registrado, inferiores apenas �s de novembro do ano passado, quando chegaram a R$ 2,380 bilh�es.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (3, 1, 'Tend�ncia de im�veis menores inspira Casa Cor S�o Paulo.', 'A Casa Cor deste ano segue uma tend�ncia do mercado: im�veis menores. A 22� edi��o do evento de decora��o mais badalado do Pa�s abre as portas na ter�a-feira, usa como fonte as tradicionais casas de vila, comuns na cidade, e acena como proposta de moradia para a capital com lofts min�sculos.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (4, 1, 'Classe C est� preparada para comprar casa pr�pria.', 'Pelo menos um em cada dez brasileiros pretende comprar a casa pr�pria dentro de 12 meses. Dos interessados na aquisi��o, quase a metade est� na classe C e pouco mais de um ter�o (35%) dos futuros propriet�rios t�m entre 25 e 34 anos.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (5, 1, 'Feir�o da Caixa come�a nesta quarta em SP com mais de 90 mil im�veis.', 'Mais de 90 mil im�veis estar�o � venda a partir desta quarta-feira (14) no Feir�o Caixa da Casa Pr�pria, realizado pela Caixa Econ�mica Federal em S�o Paulo. A quarta edi��o do evento ocorre tamb�m em outras nove cidades do pa�s.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (6, 1, 'Feir�o da casa pr�pria dobra oferta e vai oferecer 150 mil im�veis em SP', 'S�O PAULO - Quem mora em S�o Paulo e ainda paga aluguel deve come�ar a pensar em investir na casa pr�pria. A cidade vive um boom imobili�rio e um pr�dio novo � lan�ado a cada dia na cidade. Os bairros campe�es de novas constru��es s�o Mooca, Tatuap�, Morumbi, Lapa, Vila Leopoldina, Vila Romana.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (7, 1, 'Caixa financia 66 mil im�veis no primeiro trimestre e reabre Feir�o da Casa Pr�pria.', 'Bras�lia - A Caixa Econ�mica Federal abre, na semana que vem, em seis capitais, a edi��o deste ano do Feir�o da Casa Pr�pria, com o objetivo de impulsionar o mercado de im�veis residenciais, no qual investiu R$ 3,2 bilh�es, de janeiro a mar�o deste ano, no financiamento de 66 mil moradias.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (8, 1, 'Juros ainda mais baixos.', 'O mercado imobili�rio est� mais aquecido e o bom desempenho pode ser verificado nos n�meros de lan�amentos e de cr�dito que beneficiam os interessados na compra do im�vel. Atualmente, j� � poss�vel encontrar taxa de 6% ao ano mais TR (Taxa Referencial).', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO
INSERT INTO "msf"."rssitem" ("id_rssitem", "id_rss", "str_tituloitem", "str_descricaoitem", "dt_publicacao") VALUES (9, 1, 'BB quer financiar R$ 2 bilh�es em im�veis este ano.', 'A dire��o do BB (Banco do Brasil) confirmou nesta segunda-feira (dia 5) que vai ingressar no SFH (Sistema Financeiro de Habita��o), segmento que usa recursos da poupan�a para financiar a compra de im�veis. A estr�ia est� prevista para junho, e a maior institui��o financeira do Pa�s.', cast(to_char(CURRENT_TIMESTAMP,'YYYY-MM-DD HH:MI:SS' )as timestamp));
-- GO





COMMIT;
-- GO
